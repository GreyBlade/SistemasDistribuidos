﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DivisaSolution.Service
{
    interface IDivisaService
    {
        string DivisaExist(string divisa);
    }
}
